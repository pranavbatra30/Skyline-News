package com.example.skylinenews;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.skylinenews.adapter.NewsAdapter;

import java.util.ArrayList;
import java.util.List;

public class LikedNewsActivity extends AppCompatActivity {
    private RecyclerView likedNewsRecyclerView;
    private NewsAdapter newsAdapter;
    private NewsDatabase mDatabase;
    private NewsDao mNewsDao;
    private List<News> likedNewsList;
    private Thread loadLikedNewsThread;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_liked_news);

        likedNewsRecyclerView = findViewById(R.id.liked_news_recycler_view);
        likedNewsRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        mDatabase = NewsDatabase.getDatabase(this);
        mNewsDao = mDatabase.newsDao();

        loadLikedNews();
    }

    private void loadLikedNews() {
        loadLikedNewsThread = new Thread(() -> {
            List<NewsEntity> likedNewsEntities = mNewsDao.getAllNews();
            likedNewsList = new ArrayList<>();
            for (NewsEntity entity : likedNewsEntities) {
                if (Thread.currentThread().isInterrupted()) {
                    return;  // stops processing if the thread has been interrupted
                }
                likedNewsList.add(new News(
                        entity.getTitle(),
                        entity.getSection(),
                        entity.getDate(),
                        entity.getUrl()
                ));
            }

            runOnUiThread(() -> {
                newsAdapter = new NewsAdapter(this, likedNewsList);
                likedNewsRecyclerView.setAdapter(newsAdapter);
            });
        });
        loadLikedNewsThread.start();
    }
    @Override
    protected void onStop() {
        super.onStop();
        if (loadLikedNewsThread != null) {
            loadLikedNewsThread.interrupt();
        }
    }
}
