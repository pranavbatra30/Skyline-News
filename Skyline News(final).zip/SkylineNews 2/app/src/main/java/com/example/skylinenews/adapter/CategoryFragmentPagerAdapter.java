
package com.example.skylinenews.adapter;

import android.content.Context;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.example.skylinenews.R;
import com.example.skylinenews.fragment.HomeFragment;
import com.example.skylinenews.fragment.SportFragment;
import com.example.skylinenews.fragment.WorldFragment;
import com.example.skylinenews.utils.Constants;


public class CategoryFragmentPagerAdapter extends FragmentPagerAdapter {

    private Context mContext;

    public CategoryFragmentPagerAdapter(Context context, FragmentManager fm) {
        super(fm);
        mContext = context;
    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case Constants.HOME:
                return new HomeFragment();
            case Constants.WORLD:
                return new WorldFragment();
            case Constants.SPORT:
                return new SportFragment();
            default:
                return null;
        }
    }


    @Override
    public int getCount() {
        return 3;
    } // Total number of pages

    @Override
    public CharSequence getPageTitle(int position) { // Return Page Title
        int titleResId;
        switch (position) {
            case Constants.HOME:
                titleResId = R.string.ic_title_home;
                break;
            case Constants.WORLD:
                titleResId = R.string.ic_title_world;
                break;
            case Constants.SPORT:
                titleResId = R.string.ic_title_sport;
                break;
            default:
                titleResId = R.string.ic_title_home;
                break;
        }
        return mContext.getString(titleResId);
    }
}