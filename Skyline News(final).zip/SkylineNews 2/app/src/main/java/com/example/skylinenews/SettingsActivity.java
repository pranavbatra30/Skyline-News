
package com.example.skylinenews;


import static com.example.skylinenews.utils.Constants.API_KEY;
import static com.example.skylinenews.utils.Constants.API_KEY_PARAM;
import static com.example.skylinenews.utils.Constants.FORMAT;
import static com.example.skylinenews.utils.Constants.FORMAT_PARAM;
import static com.example.skylinenews.utils.Constants.PAGE_SIZE_PARAM;
import static com.example.skylinenews.utils.Constants.QUERY_PARAM;
import static com.example.skylinenews.utils.Constants.SECTION_PARAM;
import static com.example.skylinenews.utils.Constants.SHOW_FIELDS;
import static com.example.skylinenews.utils.Constants.SHOW_FIELDS_PARAM;
import static com.example.skylinenews.utils.Constants.SHOW_TAGS;
import static com.example.skylinenews.utils.Constants.SHOW_TAGS_PARAM;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.view.MenuItem;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.app.AlertDialog;

import com.example.skylinenews.utils.Constants;


// The activity that appears when a settings icon is clicked on.

public class SettingsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings_activity);

        // Navigate with the app icon in the action bar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }

    public static class NewsPreferenceFragment extends PreferenceFragment
            implements Preference.OnPreferenceChangeListener {

        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            addPreferencesFromResource(R.xml.settings_main);

            // Find the preference for number of items
            Preference numOfItems = findPreference(getString(R.string.settings_number_of_items_key));
            // bind the current preference value to be displayed
            bindPreferenceSummaryToValue(numOfItems);

            // Find the "color theme" Preference object according to its key
            Preference colorTheme = findPreference(getString(R.string.settings_color_key));
            // Update the summary so that it displays the current value stored in SharedPreferences
            bindPreferenceSummaryToValue(colorTheme);

            // Find the "text size" Preference object according to its key
            Preference textSize = findPreference(getString(R.string.settings_text_size_key));
            // Update the summary so that it displays the current value stored in SharedPreferences
            bindPreferenceSummaryToValue(textSize);
        }

        @Override
        public boolean onPreferenceChange(Preference preference, Object value) {
            String stringValue = value.toString();
            // Update the summary of a ListPreference using the label
            if (preference instanceof ListPreference) {
                ListPreference listPreference = (ListPreference) preference;
                int prefIndex = listPreference.findIndexOfValue(stringValue);
                if (prefIndex >= 0) {
                    CharSequence[] labels = listPreference.getEntries();
                    preference.setSummary(labels[prefIndex]);
                }
            } else {
                preference.setSummary(stringValue);
            }

            // Check if the preference value has actually changed before displaying the confirmation dialog
            SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
            String currentValue = preferences.getString(preference.getKey(), "");
            if (!currentValue.equals(stringValue)) {
                // Display a confirmation dialog before applying the preference change
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setTitle("Confirm change");
                builder.setMessage("Are you sure you want to apply this change?");
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Save the new preference value
                        preferences.edit().putString(preference.getKey(), stringValue).apply();

                        // Display a toast to let the user know that their setting has been changed
                        Toast.makeText(getActivity(), "Setting changed!", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Reset the preference value to the previous value
                        preference.setSummary(currentValue);
                    }
                });
                builder.setCancelable(false); // Prevent the dialog from being canceled by clicking outside of it
                builder.show();
            }

            return false; // Return false to prevent the preference value from being changed immediately
        }


        private void bindPreferenceSummaryToValue(Preference preference) {
            // Set the current NewsPreferenceFragment instance to listen for changes to the preference
            // we pass in using
            preference.setOnPreferenceChangeListener(this);

            // Read the current value of the preference stored in the SharedPreferences on the device,
            // and display that in the preference summary
            SharedPreferences preferences =
                    PreferenceManager.getDefaultSharedPreferences(preference.getContext());
            String preferenceString = preferences.getString(preference.getKey(), "");
            onPreferenceChange(preference, preferenceString);
        }

        // Go back to the MainActivity when up button in action bar is clicked on.
        @Override
        public boolean onOptionsItemSelected(MenuItem item) {
            switch (item.getItemId()) {
                case android.R.id.home:
                    return true;
            }
            return super.onOptionsItemSelected(item);
        }
    }

    public static Uri.Builder getPreferredUri(Context context) {
        SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(context);

        // getString retrieves a String value from the preferences. The second parameter is the
        // default value for this preference.
        String numOfItems = sharedPrefs.getString(
                context.getString(R.string.settings_number_of_items_key),
                context.getString(R.string.settings_number_of_items_default));

        // Parse breaks apart the URI string that is passed into its parameter
        Uri baseUri = Uri.parse(Constants.NEWS_REQUEST_URL);

        // buildUpon prepares the baseUri that we just parsed so we can add query parameters to it
        Uri.Builder uriBuilder = baseUri.buildUpon();

        uriBuilder.appendQueryParameter(QUERY_PARAM, "");
        uriBuilder.appendQueryParameter(PAGE_SIZE_PARAM, numOfItems);
        uriBuilder.appendQueryParameter(SHOW_FIELDS_PARAM, SHOW_FIELDS);
        uriBuilder.appendQueryParameter(FORMAT_PARAM, FORMAT);
        uriBuilder.appendQueryParameter(SHOW_TAGS_PARAM, SHOW_TAGS);
        uriBuilder.appendQueryParameter(API_KEY_PARAM, API_KEY);

        return uriBuilder;
    }

    public static String getPreferredUrl(Context context, String section) {
        Uri.Builder uriBuilder = getPreferredUri(context);
        return uriBuilder.appendQueryParameter(SECTION_PARAM, section).toString();
    }
}

