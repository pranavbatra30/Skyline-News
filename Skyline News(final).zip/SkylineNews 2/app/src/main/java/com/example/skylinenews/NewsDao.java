package com.example.skylinenews;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface NewsDao {

    @Query("SELECT * FROM news_table")
    List<NewsEntity> getAllNews();

    @Insert
    void insert(NewsEntity news);

    @Delete
    void delete(NewsEntity news);

}
