
package com.example.skylinenews.fragment;

public class HomeFragment extends BaseArticlesFragment {

    public static final String LOG_TAG = HomeFragment.class.getName();

}
