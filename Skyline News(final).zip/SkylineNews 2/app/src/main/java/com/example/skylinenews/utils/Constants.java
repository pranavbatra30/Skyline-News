package com.example.skylinenews.utils;

// Class to store Constants for the app.

public class Constants {

    private Constants() {
    }

    static final String JSON_KEY_RESPONSE = "response";
    static final String JSON_KEY_RESULTS = "results";
    static final String JSON_KEY_WEB_TITLE = "webTitle";
    static final String JSON_KEY_SECTION_NAME = "sectionName";
    static final String JSON_KEY_WEB_PUBLICATION_DATE = "webPublicationDate";
    static final String JSON_KEY_WEB_URL = "webUrl";
    static final String JSON_KEY_TAGS = "tags";
    static final String JSON_KEY_FIELDS = "fields";
    static final String JSON_KEY_THUMBNAIL = "thumbnail";
    static final String JSON_KEY_TRAIL_TEXT = "trailText";

    static final int READ_TIMEOUT = 10000; /* milliseconds */

    static final int CONNECT_TIMEOUT = 15000; /* milliseconds */

    static final int SUCCESS_RESPONSE_CODE = 200;

    static final String REQUEST_METHOD_GET = "GET";

    public static final String NEWS_REQUEST_URL = "https://content.guardianapis.com/search";

// Parameters
    public static final String QUERY_PARAM = "q";
    public static final String ORDER_BY_PARAM = "order-by";
    public static final String PAGE_SIZE_PARAM = "page-size";
    public static final String ORDER_DATE_PARAM = "order-date";
    public static final String FROM_DATE_PARAM = "from-date";
    public static final String SHOW_FIELDS_PARAM = "show-fields";
    public static final String FORMAT_PARAM = "format";
    public static final String SHOW_TAGS_PARAM = "show-tags";
    public static final String API_KEY_PARAM = "api-key";
    public static final String SECTION_PARAM = "section";

    public static final String SHOW_FIELDS = "thumbnail,trailText";
    public static final String FORMAT = "json";
    public static final String SHOW_TAGS = "contributor";

// API Key
    public static final String API_KEY = "596fa874-56c0-4849-8285-7c8c78f20c58";

    public static final int DEFAULT_NUMBER = 0;
    public static final int HOME = 0;
    public static final int WORLD = 1;
    public static final int SPORT = 2;

    public static int CURRENT_TAB = HOME;

}
